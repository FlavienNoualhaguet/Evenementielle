/*
 * Copyright (c) 2016 Stéphane Conversy - ENAC - All rights Reserved
 */
package fr.liienac.statemachine.event;

/**
 * Created by conversy on 11/02/15.
 */
public class Event {
}
